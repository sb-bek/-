const list = [];
const addButton = document.querySelector('#button');
const input = document.querySelector('#input');


function change(id) {
  const item = list.findIndex((d) => {
    if(d.id === id) {
      return true
    }
  })
  const text = prompt("текст для изменений");
  list[item].text = text;
  render()
}


function render() {
  const mainDiv = document.createElement('div');
  mainDiv.setAttribute('class', 'list');

  for(let i = 0; i < list.length; i++) {
    const div = document.createElement('div');
    div.setAttribute('class', 'todoBlock');
    const h3 = document.createElement('h3');
    h3.innerText = list[i].text;

    div.append(h3);

    const buttons = document.createElement('div');
    buttons.setAttribute('class', 'actions');

    const changeButton = document.createElement('button') ;
    changeButton.setAttribute('class', 'change');

    changeButton.onclick = (event) => {
      event.preventDefault();



      change(list[i].id)
    }
    changeButton.innerText = "Change";


    const deleteButton = document.createElement('button');
    deleteButton.setAttribute('class', 'delete')
    deleteButton.innerText = "Delete";


    buttons.append(changeButton, deleteButton);

    div.append(buttons);

    mainDiv.append(div);
  }
  console.log(mainDiv)

  const form = document.querySelector('.form')
  form.append(mainDiv);
}

function headleClick(event){
  event.preventDefault();

  const obj = {
    id: list.length + 1,
    text: input.value
  };
  list.push(obj);
  console.log(list);
  render();

}

addButton.addEventListener('click', headleClick);

