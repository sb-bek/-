const postContainerEl = document.getElementById("posts-container");
const filter = document.getElementById("filter");
const loader = document.getElementById("loader");

let limit = 10;
let page = 1;
let loaderIndicate = false;
let dataFromback = [];

const getData = async () => {
    const response = await fetch(
        `https://jsonplaceholder.typicode.com/posts?_limit=${limit}&_page=${page} `
    );
    const data = await response.json();
    page++;

    dataFromback = [...dataFromback, ...data];

    return data;
};

const renderItem = ({ id, title, body}) => {
    return`
    <div class="post">
        <div class="number">${id}</div>

        <div class="post_info">
        <h2 class="">${title}</h2>
        <p class="post_body">${body}</p>
        </div>
    </div>
    `;
};

const renderPosts = () => {
    loaderIndicate = true;
    loader.classList.toggle("show");

    getData()
    .then(
        (data) => (
            postContainerEl.innerHTML += data.reduce(
                (itemsTamplate, item) => (itemsTamplate += renderItem(item)),""
            )
        )
    )
    .finally(() => {
        loader.classList.toggle("show")
        loaderIndicate = false;
    });

};

const scrollCheck = () => {
    if (loaderIndicate) {
        return;
    }

    const {scrollTop, scrollHeight, clientHeight } = document.documentElement;

    if (scrollTop + clientHeight >= scrollHeight) {
        renderPosts();
    }
};
const searchPost = (event) => {
    console.log(event.target.value);

    const term = event.target.value.toLowerCase();
    const filteredPost = dataFromback.filter(({title}) => title.toLowerCase().indexOf(term) > -1);
    postContainerEl.innerHTML = filteredPost.reduce((itemsTamplate, item) => (itemsTamplate += renderItem
        (item)),
    "")
};


window.addEventListener("scroll", scrollCheck)
filter.addEventListener("input", searchPost)
renderPosts()