import WithService from "./withService";

export { WithService };
