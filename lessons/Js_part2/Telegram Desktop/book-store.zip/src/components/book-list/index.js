import React, { useEffect } from "react";
import { connect } from "react-redux";

import {WithService} from "../hoc-helpers"
import { BookListItem } from "../";
import { booksLoaded } from "../../redux-act";

import "./styles.module.scss";

const BookList = ({ books, storeService, onBooksLoaded }) => {
  useEffect(() => {
    storeService.getBooks().then((data) => onBooksLoaded(data));
  }, []);

  return (
    <ul>
      {books.map((el) => (
        <li key={`book-${el.id}`}>
          <BookListItem book={el} />
        </li>
      ))}
    </ul>
  );
};

const mapStateToProps = (state) => {
  return {
    books: state.books,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onBooksLoaded: (books) => dispatch(booksLoaded(books)),
  };
};


export default WithService(connect(mapStateToProps, mapDispatchToProps)(BookList));
