import React from "react";

import BookList from "../components/book-list";

const Main = () => {
  return (
    <>
      <BookList />
    </>
  );
};

export default Main;
